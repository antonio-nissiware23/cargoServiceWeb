<?php
phpinfo()
?>
